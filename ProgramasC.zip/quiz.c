#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    int ans1, ans2, ans3, ans4, ans5;
    int point1, point2, point3, point4, point5;
    int total = 0;

    system("cls");

    printf("Bem vindo ao jogo\n\n");

    printf("> Pressione 7 para iniciar o jogo\n");
    printf("> Pressione 0 para sair do jogo\n");

    scanf("%d", &i);

    if(i==7)
    {
        printf("O jogo comecou\n\n");
    }
    else if (i==0)
    {
                printf("O jogo acabou\n\n");
    }
    else
    {
        printf("Invalido\n\n");
    }
    
    if(i==7)//Se a opção for 7, o jogo é iniciado e todo o escopo abaixo deve ser executado
    {
        printf("\n--------------------------------------------\n");
        printf("1 --> Qual foi o primeiro motor de busca na internet?\n\n");
        printf("1) Google\n");
        printf("2) Archie\n");
        printf("3) Wais\n");
        printf("4) Altavista\n");

        printf("Digite sua resposta: ");
        scanf("%d", &ans1);
        printf("\n\n");
        if(ans1 == 2)
        {
            printf("Resposta correta!!!\n");
            point1 = 5;
            total += point1;
            printf("Voce marcou %d pontos.\n", point1);
        }
        else
        {
            printf("Resposta errada!\n");
            point1 = 0;
            printf("Voce marcou %d pontos.\n", point1);
        }//Final pergunta 1

        printf("\n--------------------------------------------\n");
        printf("2 --> Qual foi o primeiro web browser inventado em 1990?\n\n");
        printf("1) Internet Explorer\n");
        printf("2) Mosaic\n");
        printf("3) Mozilla\n");
        printf("4) Nexus\n");

        printf("Digite sua resposta: ");
        scanf("%d", &ans2);
        printf("\n\n");
        if(ans2 == 4)
        {
            printf("Resposta correta!!!\n");
            point2 = 5;
            total += point2;
            printf("Voce marcou %d pontos.\n", point2);
        }
        else
        {
            printf("Resposta errada!\n");
            point2 = 0;
            printf("Voce marcou %d pontos.\n", point2);
        }//Final pergunta 2

        printf("\n--------------------------------------------\n");
        printf("3 --> Qual foi o primeiro virus de computador conhecido?\n\n");
        printf("1) Rabbit\n");
        printf("2) Creeper Virus\n");
        printf("3) Elk Cloner\n");
        printf("4) SCA Virus\n");

        printf("Digite sua resposta: ");
        scanf("%d", &ans3);
        printf("\n\n");
        if(ans3 == 2)
        {
            printf("Resposta correta!!!\n");
            point3 = 5;
            total += point3;
            printf("Voce marcou %d pontos.\n", point3);
        }
        else
        {
            printf("Resposta errada!\n");
            point3 = 0;
            printf("Voce marcou %d pontos.\n", point3);
        }//Final pergunta 3

        printf("\n--------------------------------------------\n");
        printf("4 --> Firewall no cumputador eh usado para?\n\n");
        printf("1) Seguranca\n");
        printf("2) Transmissao de dados\n");
        printf("3) Monitoramento\n");
        printf("4) Autenticacao\n");

        printf("Digite sua resposta: ");
        scanf("%d", &ans4);
        printf("\n\n");
        if(ans4 == 1)
        {
            printf("Resposta correta!!!\n");
            point4 = 5;
            total += point4;
            printf("Voce marcou %d pontos.\n", point4);
        }
        else
        {
            printf("Resposta errada!\n");
            point4 = 0;
            printf("Voce marcou %d pontos.\n", point4);
        }//Final pergunta 4

        printf("\n--------------------------------------------\n");
        printf("5 --> Qual dos seguintes nao eh um software de gerenciamento de banco de dados?\n\n");
        printf("1) Mysql\n");
        printf("2) Oracle\n");
        printf("3) Cobal\n");
        printf("4) Sybase\n");

        printf("Digite sua resposta: ");
        scanf("%d", &ans5);
        printf("\n\n");
        if(ans5 == 3)
        {
            printf("Resposta correta!!!\n");
            point5 = 5;
            total += point5;
            printf("Voce marcou %d pontos.\n", point5);
        }
        else
        {
            printf("Resposta errada!\n");
            point5 = 0;
            printf("Voce marcou %d pontos.\n", point5);
        }
        printf("\n--------------------------------------------\n");
        printf("Voce marcou %d pontos no total!!!\n", total);
    }
    system("pause");
}