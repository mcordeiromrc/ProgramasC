#include <stdio.h>      //printf, scanf
#include <stdbool.h>    //bool, true, false
int main(void){
    int tamanho;        //A variável tamanho será utilizada para determinar quantas posições o vetor terá
    printf("Digite a quantidade de numeros na sequencia:");
    scanf("%d", &tamanho);//armazena a quantidade digitada pelo usuário para determinar o tamanho do vetor
    int sequencia[tamanho];//O vetor sequencia[tamanho] indica que o vetor terá a quantidade de posições determinada pelo usuário

    /*Coleta dos dados: Será solicitado ao usuário um número para cada posição até preencher a quantidade de posições determinada anteriormente*/
    for (int i = 0; i < tamanho; i++){//o loop irá se repetir a quantidade de vezes que foi determinada na variável tamanho.
        printf("Digite o numero %d: ", i+1);//Será apresentada a mensagem: Digite o numero [posição+1], pois a primeira posição é zero
        scanf("%d", &sequencia[i]);//O valor digitado pelo usuário será armazenado na posição atual de i do vetor sequencia
    }

    int temp;
    bool mudanca = true;

    while (mudanca){
        mudanca = false;
        for (int i = 0; i < tamanho-1; i++){
            if (sequencia[i] > sequencia[i+1]){

                /*Realiza a troca*/
                temp = sequencia[i];
                sequencia[i] = sequencia[i+1];
                sequencia[i+1] = temp;

                mudanca = true; 
            }
        }
    }
    printf("Sequencia reordenada:\n");
    for (int i = 0; i < tamanho; i++)
        printf("%d ", sequencia[i]);
    printf("\n");
}