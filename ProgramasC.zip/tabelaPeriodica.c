#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("cls");

    int n, m, a, Exit;

    printf("\n--------------------------------------------\n");
    printf("Bem vindo(a) a Tabela Periodica Moderna!!!");
    printf("\n--------------------------------------------\n");

    printf("> Digite 1 para saber sobre um elemento\n\n");
    printf("> Digite 2 para fechar a Tabela Periodica\n\n");

    printf("Opcao desejada: ");
    scanf("%d", &n);

    if(n==1)//Caso a opção 1 seja selecionada, todo o bloco abaixo será executado
    {
        printf("> Pressione 3 para pesquisar o elemento por número atômico\n\n");

        printf("Digite: ");
        scanf("%d", &m);

        if(m==3)
        {
            printf("Digite o numero atomico do elemento a ser pesquisado: ");
            scanf("%d", &a);

            if(a==1)
            {
                printf("Name: Hidrogenio\n");
                printf("Simbolo: H\n");
                printf("Numero Atomico: 1\n");
                printf("Configuracao eletronica: 1s^1\n");
                printf("Descoberto por: Hery Cavendish\n");
                printf("Carga: +a\n");
            }
        }
    }
    else if(n==2)
    {
        printf("Voce deseja sair? (Sim/Nao)\n");
        printf("> Digite 6 para Sim\n");
        printf("> Digite 7 para Nao\n");

        printf("Digite: ");
        scanf("%d", &Exit);

        if(Exit==6)
        {
            printf("Voce tem certeza, voce quer fechar a tabela periodica? (Sim/Nao)\n");
            printf("> Digite 4 para Sim\n");
            printf("> Digite 5 para Nao\n");

            printf("Digite: ");
            scanf("%d", &Exit);

            if(Exit==4)
            {
                printf("A tabela periodica sera fechada");
            }
            else if(Exit==5)
            {
                printf("A tabela periodica nao fechou e voce pode continuar aprendendo mais sobre os elementos\n\n");

                printf("Digite o numero atomico do elemento pesquisado: ");
                scanf("%d", &a);

                if(a==1)
                {
                    printf("Name: Hidrogenio\n");
                    printf("Simbolo: H\n");
                    printf("Numero Atomico: 1\n");
                    printf("Configuracao eletronica: 1s^1\n");
                    printf("Descoberto por: Hery Cavendish\n");
                    printf("Carga: +a\n");
                }
            }
        }
        else if(Exit==7)
        {
            printf("A tabela periodica nao fechou e voce pode continuar aprendendo mais sobre os elementos\n\n");

            printf("Digite o numero atomico do elemento pesquisado: ");
            scanf("%d", &a);

            if(a==1)
                {
                    printf("Name: Hidrogenio\n");
                    printf("Simbolo: H\n");
                    printf("Numero Atomico: 1\n");
                    printf("Configuracao eletronica: 1s^1\n");
                    printf("Descoberto por: Hery Cavendish\n");
                    printf("Carga: +a\n");
                }
        }
    }

    system("pause");
    return 0;
}