#include <stdio.h>
#include <stdlib.h>

int main() {
    int i;
    float valorInicial = 0.01, valorFinal = 0.01;

    for(i = 1; i <= 29; i++){
        valorInicial = valorInicial * 2;
        valorFinal += valorInicial;
    }

    printf("Valor em centavos: %d\n", valorFinal);
    printf("R$%.2f\n\n", valorFinal / 100.0);
}