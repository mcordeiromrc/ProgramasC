#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int i, num;
    char continua;

    do{
        system("cls");
        printf("Digite o numero: ");
        scanf("%i", &num);
        for(i=1;i<=10;i++){
            printf("%i x %i = %i\n", num, i,(num*i));
        }
        printf("Diseja continuar com outro numero? [s/n]: ");
        scanf(" %c", &continua);
    } while(continua == 's'); 
}