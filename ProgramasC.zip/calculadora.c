#include <stdio.h>
#include <stdlib.h>

int main() {
    //declaração de variáveis
    int opcao, num1, num2;

    //estrutura de repetição para exibir o menu de opções, solicitando a opção do usuário e realizar 
    //a operação a ser realizada, 
    do {
        //função para limpar a tela do prompt
        system("cls");
        //menu com as opções que o usuário deve selecionar
        printf("\n1 - Soma\n2 - Subtracao\n3 - Multiplicacao\n4 - Divisao\n0 - Sair\n\n");
        //leitura da opção
        scanf("%d", &opcao);
        //condicional para forçar o usuário a selecionar opção de 0 a 4
        if(opcao > 0 && opcao < 5){
            printf("Digite dois valores: ");
            //leitura dos dois números que serão calculados
            scanf("%d%d",&num1, &num2);
        }
        // switch_case para selecionar o calculo que será realizado
        switch(opcao) {
        case 0:
            printf("Saindo...\n");
            break;
        case 1:
            printf("Soma: %d\n", num1 + num2);
            break;
        case 2:
            printf("Subtracao: %d\n", num1 - num2);
            break;
        case 3:
            printf("Multiplicacao: %d\n", num1 * num2);
            break;
        case 4:
            //caso o segundo número digitado pelo usuário for zero, o programa irá verificar que o número digitado é zero
            //e irá informar que não pode haver divisão por zero e irá solicitar ao usuário a digitar o valor novamente.
            while(num2 == 0) {
                printf("Nao existe divisao por zero!\nDigite outro valor: ");
                scanf("%d", &num2);
            }
            printf("Divisao: %d\n", num1 / num2);
            break;
        default:
            printf("Opcao inválida.\nDigite outra opcao: ");
        }
    } while(opcao != 0);
}