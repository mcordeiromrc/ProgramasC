#include <stdio.h>
#include <stdlib.h>

int main() {
    int num, positivos = 0, negativos = 0;

    do{
        printf("Digite um valor: ");
        scanf("%d", &num);

        if(num > 0)
            positivos++;
        if(num < 0)
            negativos++;

    }while(num != 0);

    printf("Positivos: %d\nNegativos: %d\n\n", positivos, negativos);
}