#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/**
 * Aula 113: Exercicio 03
 * 3) Escrever um programa que lê um vetor N dee tamanho 6 e o imprema na tela.
 * Em seguida, troque o 1º elemento com  ultimo, o 2º com o penultimo, ... até o
 * 2º com o 3º. Imprima o vetor N modificado
 * 
 * indice: 0    1   2   3   4   5
 * vetor: 14   52  36  54  78  84
 * vetor: 84   78  54  36  52  14
*/
int main() {

    int a, fim = 5, copia, vetor[6];

    // lê valores do teclado e salva no vetor
    for(a = 0; a < 6; a++){
        printf("digite %d: ", a);
        scanf("%d", &vetor[a]);
    }

    // imprime o vetor lido
    printf("\nVetor original: ");
    for(a = 0; a < 6; a++){
        printf("%2d ", vetor[a]);
    }

    // faz a troca dos elementos do vetor
    for(a = 0; a < 3; a++){//O laço será repetido 4 vezes
        copia = vetor[a];//Copia o conteúdo atual de vetor[a] para a variável auxiliar copia
        vetor[a] = vetor[fim];//Copia o conteúdo atual de vetor[fim] para vetor[a]
        vetor[fim] = copia;//Copia o conteúdo atual de copia para vetor[fim]
        fim--;//Decrementa a variável fim em 1
    }

    // imprime o vetor novamente (agora modificado)
    printf("\nVetor modificado: ");
    for(a = 0; a < 6; a++){
        printf("%2d ", vetor[a]);
    }

    printf("\n");
    system("pause");
    return 0;
}