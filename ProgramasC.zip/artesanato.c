#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, maisVendido = 0, quant[10];
    float valorTotal = 0, valorParcial, valor[10];

    //Recebe o valor unitário e a quantidade vendida de 10 produtos
    for(i=0;i<10;i++){
        printf("> Produto %d:\n", i+1);
        printf("Digite valor unitario: ");
        scanf("%f", &valor[i]);
        printf("Digite a quantidade vendida: ");
        scanf("%d", &quant[i]);
        printf("--------------------------------\n");
    }

    printf("|-----------------------------------------------------------|\n");
    printf("| Qtd Vendia\tValor por Unidade    \tTotal parcial       |\n");
    printf("|-----------------------------------------------------------|\n");

    for(i=0;i<10;i++){
        valorParcial = quant[i]*valor[i];
        printf(" Vendido %d\tValor unitario R$%.2f\tValor total R$%.2f\n", quant[i], valor[i], valorParcial);
        valorTotal += valorParcial;
    }
    printf("|-----------------------------------------------------------|\n");
    printf("Valor total das vendas R$%.2f\n", valorTotal);
    printf("Comissao paga ao vendedor R$%.2f\n", valorTotal*0.05);

    for(i=0;i<10;i++){
        if(quant[i] > maisVendido)
            maisVendido = quant[i];
    }

    for(i=0;i<10;i++){
        if(quant[i] == maisVendido)
            printf("Posicao: %d\tValor R$%.2f\n", valor[i]);
    }

    system("pause");
    return 0;
}