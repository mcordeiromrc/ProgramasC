#include <stdio.h>
#include <stdlib.h>

int main() {
    //Declaração de variáveis
    int quantidade, i;
    float salario, totalSalarios = 0, salarioMaior = 0, salarioMenor = 99999;
    //Perguntar a quantidade de funcionários a empresa tem, se for digitado
    //valor inferior a 1 o programa não sairá do loop
    do{
        printf("Quantos funcionarios a empresa possui? ");
        scanf("%d", &quantidade);
    }while(quantidade < 0);

    for(i = 1; i <= quantidade; i++){//index começa com 1 e vai até a quantidade de funcionários digitada, incrementando 1 a cada loop
        printf("%d salario: ", i);   //Será exibida mensagem informando o valor do index atual 
        scanf("%f", &salario);       //leitura do salário atual e atribuindo à variável salario

        totalSalarios += salario;    //após a digitação do salário, ele será somado à variável totalSalarios
        if(salarioMenor > salario)   //Será verificado se o valor atual da variável salario é inferior ao valor atual da variável salarioMenor
            salarioMenor = salario;  //Se o valor atual da variável salario for inferior ao valor atual da variável salarioMenor, atribuir o valor de salario para salarioMenor
        if(salarioMaior < salario)   //Será verificado se o valor atual da variável salario é superior ao valor atual da variável salarioMaior
            salarioMaior = salario;  //Se o valor atual da variável salario for superior ao valor atual da variável salarioMaior, atribuir o valor de salario para salarioMaior
    }
    printf("Salario medio R$%.2f\n", totalSalarios/quantidade); //Para extrair a média salarial, dividir totalSalarios pela quantidadae de funcionários
    printf("Maior salario R$%.2f\n", salarioMaior);             //Exibir o maior salário que é o valor atual de salarioMaior
    printf("Menor salario R$%.2f\n\n", salarioMenor);           //Exibir o menor salário que é o valor atual de salarioMenor
}