#include <stdio.h>
#include <stdlib.h>

int main() {
    float nota = 0, soma = 0, cont = 0;
    double media = 0;

    do
    {
        printf("Digite um numero: ");
        scanf("%f", &nota);
        if(nota != 0){
            cont++;
            soma += nota;
        } else {
            break;
        }
    } while (nota > 0);
    media = (soma/cont);
    printf("A media do aluno eh: %.9f\n", media);
    system("pause");
}