#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int i;      // a variável i será usada como contador nos loops for e também como indice do vetor
    int qtd;    // a variável qtd será utilizada para armazenar a quantidade de posições que o vetor terá, informação fornecida pelo usuário
    int copia;  // a variável copia será utilizada como variável auxiliar para receber temporariamente o valor do vetor em sua posição atual.
    /*
    a variável troca é uma variável booleana que será utilizada como chave de controle do número de repetições que o algoritmo
    de ordenação será executado até que todos os valores estejam devidamente organizados. Será usada em um loop do-while que terá o for 
    de ordenação dentro dele.
    */
    int troca;  

    //Solicita ao usuário a quantidade de valores que serão digitados, isso consequentemente será utilizado para determinar a quantidade de 
    //posições do vetor.
    printf("Digite a quantidade de valores: ");
    scanf("%d", &qtd);

    int vet[5];//o vetor deveria ser montado como vet[qtd], mas por uma uma falha de apresentação das posições do vetor no GDB, tive que colocar o número.

    // Loop de leitura dos valores e consequênte atribuição desses valores em cada posição do vetor
    for (i = 0; i < qtd; i++)//vai repitir de zero até o valor estipulado em qtd, será repitido qtd vezes.
    {
        printf("Digite o valor de vet[%d]: ", i);// exibe a mensagem incluindo a posição atual do vetor
        scanf("%d", &vet[i]); // atribui o valor digitado à posição atual do vetor
    }

    // Loop de exibição dos valores contidos em cada posição do vetor, um espelho do que foi digitado anteriormente
    for (i = 0; i < qtd; i++) // vai de zero até qtd
    {
        printf("Valor atual em vet[%d] = %d\n", i, vet[i]); // exibe a mensagem, exibe a posição atual do vetor e o valor contido nesta posição
    }

    /**
     * Nesta seção que será executado o algoritmo de ordenação baseado em Bubble sort
     * 
    */
    do// Repetição realizada até que a ultima sequênia de loop for abaixo seja realizada para garantir que todas as ordenações do algoritmo sejam realizadas
    {
        troca = 0; //o valor troca igual a zero irá finalizar o loop caso todo o for tenha sido efetuado
        for (i = 0; i < qtd; i++)
        {
            if (vet[i] > vet[i + 1])
            {
                copia = vet[i];
                vet[i] = vet[i + 1];
                vet[i + 1] = copia;
                troca = 1;
            }
        }
    } while (troca);

    for (i = 0; i < qtd; i++)
    {
        printf("Valor atual de vet[%d] apos ordenacao:  %d\n", i, vet[i]);
    }
    system("pause");
}