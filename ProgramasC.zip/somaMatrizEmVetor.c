#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int l, c, soma, mat[5][10], somaLinhas[5], somaColunas[10];

    srand(time(NULL));

    //preenche a matriz nas posições l(linha) e c(coluna) com números aleatórios
    for(l=0;l<5;l++){//percore uma linha a cada preenchimento de coluna
        for(c=0;c<10;c++){//preenche as 10 posições iniciando de 0 até 9
            mat[l][c] = rand() % 100; //incere um valor de até 2 digitos gerado aleatoriamente na posição atual da matriz na linha e coluna atual
        }
    }

    //letra a) soma das linhas
    //após o preenchimento das colunas e linhas com valores gerados aleatóriamente, este algoritimo irá percorrer cada posição das colunas 
    //e irá acumular a soma de cada valor da linah na variável soma e ao final irá atribuir o total no vetor somaLinhas em sua posição atual.
    for(l=0;l<5;l++){//percorre a cada repetição uma linha
        soma = 0;//zera a variável soma para que não haja lixo de memória
        for(c=0;c<10;c++){// percorre cada coluna da pozição 0 até a posição 9 da linha atual
            soma += mat[l][c];// soma o valor contido na posição atual da matriz e atribui o valor para a variável soma
        }
        somaLinhas[l] = soma;// atribui o valor atual de soma para a variável soma Linha em sua posição atual
    }

    //letra b> soma das colunas
    for(c=0;c<10;c++){
        soma = 0;
        for(l=0;l<5;l++){
            soma += mat[l][c];
        }
        somaColunas[c] = soma;
    }

    //impressão das estruturas
    printf("\nMatriz\n");
    for(l=0;l<5;l++){
        for(c=0;c<10;c++){
            printf("%2d ", mat[l][c]);
        }
        printf("\n");
    }

    printf("\n\nVetor com a soma das linhas:\n");
    for(l = 0;l<5;l++){
        printf("Linha %d: %d\n", l,somaLinhas[l]);
    }

    printf("Vetor com a soma das colunas:\n");
    for(c=0;c<10;c++){
        printf("Coluna %d: %d\n", c, somaColunas[c]);
    }
}