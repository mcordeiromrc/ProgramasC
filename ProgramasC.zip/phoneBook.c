#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, p, d;
    char n[50], add[50], na[50], addr[50];
    int ag, ph, da;

    printf("WELCOME TO PHONE BOOK\n\n");

    printf("MENU\n");
    
}