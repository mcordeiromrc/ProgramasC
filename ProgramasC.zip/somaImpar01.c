#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int i, soma = 0, soma2 = 0;

    for(i =1; i <= 1000; i++)// contagem de 1 até 1000 com incremento de 1 a cada repetição
        if(i % 2 == 1) // verifica se o resto de i * 2 é igual a 1
            soma += i; // se for, pegue o valo ratual de i e inclua na soma

    printf("Soma dos impares de 1 a 1000: %d\n\n", soma);

    for(i =1; i <= 1000; i += 2)// contagem de 1 até 1000 com incremento de 1 a cada repetição
            soma2 += i; // se for, pegue o valo ratual de i e inclua na soma

    printf("Soma dos impares de 1 a 1000: %d\n\n", soma2);

    system("pause");
}