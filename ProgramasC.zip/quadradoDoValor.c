/**
 * Leia um valor inteiro N e apresente o quadrado de cada valor par de 1 até N
 * Assim como no exercício anterior, podemos iniciar esta repetição com 2(primeiro inteiro positivo par)
 * e fazer o incremento de 2 em 2, saltando dessa forma sempre entre os números pares até N.
*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int i, n;

    printf("Digite um valor inteiro: ");
    scanf("%d", &n);

    for(i = 2; i <= n; i+= 2)
        printf("%d ", i * i);
    printf("\n\n");
}