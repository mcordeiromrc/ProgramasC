#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    int i;
    int num2[12];

    srand(time(NULL));

    for(i=0;i<12;i++)
        num2[i] = 1 + rand() % 99;
    
    printf("\n\n");
    for(i=0;i<12;i++)
        printf("%d ", num2[i]);
    printf("\n\n");

    return 0;
}