#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    int i;
    int num2[10];

    srand(time(NULL));//esta função irá gerar uma semente que permitirá sempre trocar os números gerados pela rand()

    for(i=0;i<10;i++){
        num2[i] = rand(); //A função rand() gera números aleatórios
    }

    printf("\n\n");
    for(i=0;i<10;i++){
        printf("%d ", num2[i]);
    }
    printf("\n\n");
    return 0;
}