#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    //Variável i será usado como index do for
    //Variável x será usado para coletar a quantidade de funcionários da empresa que também será utilizada no for
    //Variável menorIdade, é iniciada intencionalmente com o valor 999 para ser usada no if de comparação com a idade do funcionario atual
    //Variável maiorIdade, é iniciada intencionalmente com o valor 0 para ser usada no if de comparação com a idade do funcionário atual
    //Variável quantM será usada incrementando a quantidade de mulheres informadas no programa
    int i, x, idade, menorIdade=999, maiorIdade = 0, quantM = 0;
    //Variável do tipo caractere sexo, usada para verificar se o sexo do funcionário é 'F' ou 'M'
    char sexo;
    //Variável salário será usada para armazenar o salário do funcionário atual
    //Variável mediaSalario será usada para armazenar a soma de cada salário digitado, para não haver lixo de memória, é iniciada em zero
    float salario, mediaSalario = 0;

    //Mensagem no prompt solicitando a quantidade de usuários
    printf("Digite a quantidade de entrevistados: ");
    //Campo de leitura da quantidade de funcionários que será atribuída para a variável x
    scanf("%d", &x);
    /**
     * Laço de repetição que será repetido no exato número de vezes da quantidade de funcionários digitada
     * a cada interação do loop for, será solicitado ao usuário a digitação da idade, sexo e salário do funcionário e atribuir o valor a sua 
     * respectiva variável.
     * 
     * O programa irá primeiramente verificar a idade do funcionário, e se a idade for menor que o valor atual da variável menorIdade, irá atribuir
     * o valor digitado para esta variável.
     * O mesmo será realizado com a variável maiorIdade
     * 
     * Logo após irá verificar se o sexo do funcionário é 'F' e se o seu salário é inferior ou igual a 2000, se for, irá incrementar o valor da 
     * variável quantM
     * 
     * Por ultimo o programa irá calcular a média salarial dividindo a variável mediaSalarial pela variável X.
    */
    for(i = 1; i <= x; i++){ //cria um laço que será repetido a quantidade de funcionários da empresa(Variável X)
        printf("Digite sua idade: "); //Solicita a idade do funcionário
        scanf("%d", &idade);//Lê a informação e atribui para a variável idade
        printf("Digite seu sexo [M/F]: ");//Solicita o sexo do funcionário
        scanf(" %c", &sexo);//Lê a informação e atribui a variável sexo
        printf("Digite seu salario: ");//Solicita o salário do funcionário
        scanf("%f", &salario);//Lê a informação e atribui a variável salario

        //soma dos salários: Irá somar a mediaSalario o valor atual da variável salário a cada execução do for
        mediaSalario += salario;

        if(menorIdade > idade)//verifica se o valor atual de menorIdade é maior que a idade informada do funcionário atual
            menorIdade = idade;// se menorIdade for realmente maior que o valor atual da variável idade, atribui ao valor de idade à menorIdade
        if(maiorIdade < idade)//verifica se o valor atual de maiorIdade é menor que a idade informada do funcionário atual
            maiorIdade = idade;// se maiorIdade for realmente menor que o valor atual da variável idade, atribui ao valor de idade à maiorIdade
        
        if(sexo == 'F' && salario <= 2000)//Verifica se o valor atual da variável sexo é igual a 'F' e o valor atual da variável salario é menor ou igual a 2000
            quantM++; //Se sexo for igual a 'F' e salario for menor ou igual a 2000, incrementar o valor de quantM em 1.
    }
    printf("Media salarial R$%.2f\n", mediaSalario / x);//Exibir a mensagem com o resulgado de mediaSalario dividigo pela quantidade de funcionários para exibir a média salarial
    printf("Menor idade: %d\nMaior idade: %d\n", menorIdade, maiorIdade);
    printf("Quantidade de mulheres com salario ate R$2000,00: %d\n\n", quantM);
}