#include <stdio.h>
#include <stdlib.h>

/**
 * Escreva um programa que leia dois valores X e Y. A seguir, mostre uma sequência de 1 até Y, passando para a próxima linha a cada X números.
 * Neste caso o programa irá imprimir os números em seguência de 1 até o número até o número digitado em Y.
 * O programa irá imprimir a disposição dos números em colunas e linhas, onde o número de colunas por linha será o valor da variável X
 * e as linhas serão preenchidas até finalizar a numeração informada na variável Y.
 * Para que o programa finalise o preenchimento de uma linha com a quantidade certa de colunas conforme digitado em X, será usado 
 * uma instrução condicional verificando se o RESTO DE I POR X É IGUAL A ZERO. 
*/
int main(void) {

    int x, y, i;

    printf("Digite X e Y: ");
    scanf("%d%d", &x, &y);

    for(i = 1; i <= y; i++){//I inicia em 1, enquanto i for menor ou igual ao valor da variável Y, incremente mais 1 a Y.
        printf("%3d ", i);  //Imprima o valor atual de i 
        if(i % x == 0) //Se o resto de I por X for igual a ZERO, o program irá quebrar para uma próxima linha.
            printf("\n");
    }
    return 0;
}