#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("\n-----------------------------------------\n");
    printf("1 - Logar   2 - Cadastrar   3 - Imprimir\n");
    printf("-----------------------------------------\n");

    printf("\n\nPressione qualquer tecla para continuar...");
    getchar();
}