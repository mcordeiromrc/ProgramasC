#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int valor, positovos = 0, negativos = 0;

    printf("Digite o primeiro valor: ");
    scanf("%d", &valor);

    if(valor < 0)
        negativos++;// sinônimo de -> negativos += 1; negativos = negativos + 1;
    else
        positovos++;

    printf("Digite o segundo valor: ");
    scanf("%d", &valor);

    if(valor < 0)
        negativos++;
    else
        positovos++;

    printf("Digite o terceiro valor: ");
    scanf("%d", &valor);

    if(valor < 0)
        negativos++;
    else
        positovos++;

    printf("Digite o quarto valor: ");
    scanf("%d", &valor);

    if(valor < 0)
        negativos++;
    else
        positovos++;

    printf("Digite o quinto valor: ");
    scanf("%d", &valor);

    if(valor < 0)
        negativos++;
    else
        positovos++;

    printf("\nPositivos: %d\nNegativos: %d\n", positovos, negativos);

    system("pause");
}