#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main (void) {
    //vetor do tipo char com 100 posições
   char linha[100];
   //variável n com o valor inicial 0
   int n = 0;
   //Loop infinito até condição ser realizada
   //Este loop será utilzado para receber os caracteres do usuário e armazenar cada caractere em cada posição do vetor
   while (true) {
        //vetor linha na posição atual irá receber o caractere digitado pelo usuário
      linha[n] = getchar ();
      //Se o caractere digitado na posição atual do vetor linha for um enter: Barar o loop
      if (linha[n] == '\n') break;
      // Incrementa a variavel n em 1
      n++;
   }// fim do laço caso a condição do loop seja parada.
    // Loop para exibir os caracteres digitados no vetor linha[]
   for (int i = 0; i <= n; i++)
      putchar (linha[i]);
   return EXIT_SUCCESS;
}