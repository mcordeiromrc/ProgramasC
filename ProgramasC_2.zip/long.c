#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

// O operador int só permite até 2147483647 acima disso dá esouro de memória de 4 bytes
//caso necessite de mais espaço, pode se utiilizar o long long int
//em computadores antigos, o tipo int ocupava 2bytes, e a long int já ocoupava 4 bytes

int main(void)
{
    setlocale(LC_ALL,"Portuguese");
    
    printf("Coração!\n");
}