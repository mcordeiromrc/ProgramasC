#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a = 5, b = 10, c = 0;

    printf("a: %d\tb: %d\n", a, b);

    //usando variável auxiliar c para receber o valor da variável b temporariamente
    c = b;
    b = a;
    a = c;

    printf("a: %d\tb: %d\n", a, b);
}