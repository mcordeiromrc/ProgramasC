#include <stdio.h>
#include <stdlib.h>

/*
    Uma empresa contrata um encanador a R$45,00 por dia. Faça um programa
    que solicite o número de dias trabalhados pelo encanador e imprima a
    quantia liquida que deverá ser paga, sabendo que são descontados 8% de
    imposto de renda
*/

int main(void)
{
    float dias, valorFinal, desconto;

    printf("Quantos dias trabalhados? ");
    scanf("%f", &dias);

    valorFinal = (dias*45);
    desconto = (valorFinal = 8)/100;
    valorFinal = valorFinal - desconto;

    printf("Dias trabalhados: %f", valorFinal);

    //printf("A receber: R$%.2f\nDesconto R$%.2f\n", valorFinal, desconto);
}