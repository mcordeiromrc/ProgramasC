#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a, b, c, maior, menor;

    printf("Digiter tres valores: ");
    scanf("%d%d%d", &a, &b, &c);

    // Segunda versão
    //As variáveis maior e menor são iniciadas com o valor de a
    menor = a;
    maior = a;

    if(menor > b)
        menor = b;
    if(menor > c)
        menor = c;

    if(maior < b)
        maior = b;
    if(maior < c)
        maior = c;
    
    printf("Segunda versao\nMenor: %d\tMaior: %d\n", menor, maior);
}