#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int num;

    printf("Digite um valor qualquer: ");
    scanf("%i", &num);

    if(num % 2 == 0 || num % 3 == 0 || num % 5 == 0)
        printf("Divisivel por 2, 3 ou 5.\n");
    else
        printf("Nao divisivel por 2, 3 ou 5.\n");
}