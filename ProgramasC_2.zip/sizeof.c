#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    float x = 1.0;

    printf("Tamanho de um float na memoria: %d bytes\n", sizeof x); //não precisa colocar x entre parenteses pois você quer saber o tamanho de memória da variável
    printf("Tamanho em memoria de um tipo int %d bytes\n", sizeof(int)); //deve colocar entre parenteses pois você quer saber o tamanho de memória do tipo de dado.
}