#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int idade;
    char sexo;

    printf("Digite seu sexo f ou m: ");
    scanf("%c", &sexo);
    printf("Digite sua idade: ");
    scanf("%d", &idade);

    if(sexo == 'm'){
        if(idade == 18)
            printf("Alistamento obrigatorio!\n");
        else
            printf("Dispensado!\n");
    } else {
        printf("Voce pode se alistar de forma voluntaria!\n");
    }
}