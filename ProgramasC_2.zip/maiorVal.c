#include <stdio.h>
#include <stdlib.h>
int main()
{
    //variável i que será o index, vetor de 5 posições
    int i, lista[5] = {3, 18, 2, 51, 45};
    //Criar a variável auxiliar maior que será utilizada para comparar o valor da posição atual do vetor lista[posição_atual]
    //esta variável deverá receber um novo valor sempre que o laço o comparar com outro valor contido na posição atual
    //do vetor lista[posição_atual]
    int maior = lista[0];// o vetor deve ser alimentado com uma das posições da lista de valores para que, ao ser atribuído à variável maior, o valor possa ser comparado com os outros
    //o laço for irá contar de 1 até 4, pois a posição 0 já está preenchida
    for (i = 1; i < 5; i++)
    {
        //se o valor atual de maior que atualmente vale 3 for menor que o valor atual de lista que é lista[1] que é 18
        if (maior < lista[i])
            maior = lista[i]; //atribua o valor atual de lista[1] que é 18 para a variavel maior
    }
    printf("Maior = % d\n", maior);
    return 0;
}