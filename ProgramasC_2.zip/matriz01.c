#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    int mat[100][50];
    int i,j;
    for(i=0;i<100;i++){
        for(j=0;j<50;j++){
            printf("Digite o valor de mat[%d][%d]: ", i,j);
            scanf("%d", &mat[i][j]);
        }
    }
    printf("Digite qualquer tecla para continuar...");
    getchar();

    return 0;
}