#include <stdio.h>

int main(void)
{
    unsigned int var = 4294967296;
    printf("%u", var);
}