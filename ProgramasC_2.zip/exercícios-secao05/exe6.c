#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    system("cls");
    int cont= 0, num, soma = 0;
    float media;

    do{
        printf("Digite num numero: ");
        scanf("%d", &num);

        soma += num;
        cont++;
    }while(cont < 10);
    media = (soma/cont);
    printf("A media dos %d numeros eh: %.2f\n", cont, media);
}