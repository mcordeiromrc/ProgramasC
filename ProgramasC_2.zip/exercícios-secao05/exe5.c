#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    system("cls");
    int cont= 0, num, soma = 0;

    do{
        printf("Digite num numero: ");
        scanf("%d", &num);

        soma += num;
        cont++;
    }while(cont < 10);
    printf("A soma dos %d numeros eh: %d\n", cont, soma);
}