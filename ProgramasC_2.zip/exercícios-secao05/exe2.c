#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int num = 1;

    system("cls");

    printf("Numeros de 1 a 100 utilizando FOR\n");
    for(num; num <= 100; num++){
        printf("%d ", num);
    }

    num = 1;
    printf("\nNumeros de 1 a 100 utilizando o WHILE\n");
    while(num <= 100){
        printf("%d ", num);
        num++;
    }

    num = 1;
    printf("\nNumeros de 1 a 100 utilizando o DO/WHILE\n");
    do{
        printf("%d ", num);
        num++;
    } while(num <=100);
}