#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    //criando uma variavel do tipo ponteiro para arquivo
    FILE *pont_arq;
    //Variável do tipo char que será utilizada para receber a resposta do usuário se o arquivo será criado "s" ou não criado ""
    char cria_arq; 
    //Variável matriz do tipo char que irá ser utilizada para armazenar o nome do arquivo que deseja ser criado
    char nome_arq[50];

    //Mensagem no prompt perguntando ao usuário se o arquivo deve ser criado
    printf("Deseja criar o arquivo [s/n]?: ");
    //atribui para a variael cria_arq o caractere digitado pelo usuário, lembrando que deve ser [s ou n]
    cria_arq = getchar();

    //instrução condicional que verifica se o caractere digitado foi "s", se for realiza o procedimento de criação de arquivo, se não, exibe uma mensagem e não gera nada
    if(cria_arq == 's'){ // verifica se o conteúdo da variável cria_arqui é igual a 's', se for, realize o procedimento se_SIM
        //Pensagem no prompt solicitando ao usuário do programa o nome do arquivo "nome_arquivo"."extenção"
        printf("Digite o nome do arquivo..: ");
        //a scanf() irá ler o nome digitado pelo usuário e irá armazenar a informação na variável nome_arqui
        scanf("%s", &nome_arq);
        //atribuindo ao ponteiro pont_arq a função fopen indicando como argumento o nome do arquivo desejado com o primeiro arquivo sendo o conteúdo da variável nome_arq e o segundo argumento o tipo de abertura
        pont_arq = fopen(nome_arq, "a");
        // utilizar a função fclose() para fechar o arquivo contido no ponteiro port_arq
        fclose(pont_arq);

        /**
         * Instrução condicional que será utilizada para avaliar se o arquivo foi gerado com sucesso ou se ocorreu 
         * erro no ato da criação do arquivo.
         * Se o resultado de pont_arqui for nulo: Indicar que deu erro na geração do arquivo, se não, informar que o arquivo foi não foi criado
        */
        if(pont_arq == NULL){
            printf("ERRO! O arquivo nao foi aberto!");
        } else {
            printf("O arquivo foi criado cmo sucesso...");
        }
    } else {// Se o usuário decidiu escolher 'n' para não gerar o arquivo.
        printf("Arquivo nao criado...");
    }
    getchar();
}