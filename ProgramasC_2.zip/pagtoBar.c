#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
    float valor, gorjeta, val_pagto;
    int pessoas;

    printf("Digite o valor a ser pago: ");
    scanf("%f", &valor);
    printf("Digite o percentual de gorjeta: ");
    scanf("%f", &gorjeta);
    printf("Quantidade de pessoas: ");
    scanf("%i", &pessoas);

    val_pagto = ((valor*gorjeta)/100)+valor;

    printf("Valor total: %.2f\n", val_pagto);
    printf("Valor a ser pago por pessoa: %.2f\n", val_pagto/(float)pessoas);
}