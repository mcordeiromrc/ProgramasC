#include <stdio.h>
#include<math.h>

int main() {
    //Declaração de variáveis
    float n1;
    
    //Entrada de dados
    printf ( "Digite um numero:    " );
    scanf ( "%f%*c", &n1 );
    
    //Processamento
    if ( n1 > 0 ) {
        //Saída, se n1 for maior que 0, utiliza a função sqrt(n1) para extrair a raíz quadrada de n1
        printf ( "\nRAIZ %.2f", sqrt(n1) );
    } else{
        //Saída, se n1 for menor que 0, utiliza a função pow(n1, 2) potenciar por 2 n1
        printf ( "\nPOTENCIA %.2f\n\n", pow(n1, 2) );
    }
    
    getchar();
    return 0;
}