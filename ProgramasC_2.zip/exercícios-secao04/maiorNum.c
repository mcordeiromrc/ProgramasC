#include <stdio.h>

int main(void)
{
    int num1, num2;

    printf("Digite um numero: ");
    scanf("%i", &num1);

    printf("Digite outro numero: ");
    scanf("%i", &num2);

    if(num1 > num2){
        printf("O maior numero eh: %d\n", num1);
    } else {
        printf("O maior numero eh: %d\n", num2);
    }
}