#include <stdio.h>
#include <math.h>

int main(void)
{
    int num1;
    float raiz;

    printf("Divite um numero: ");
    scanf("%d", &num1);

    if(num1 > 0){
        raiz = sqrt(num1);
        printf("A raiz guadrada de %d eh %.2f\n", num1, raiz);
    } else {
        printf("Numero invalido, digite numero positivo!\n");
    }
}