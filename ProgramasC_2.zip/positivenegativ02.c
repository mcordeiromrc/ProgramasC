#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int valor[5], positivos = 0, negativos = 0;

    for(int i = 0; i<5; i++){
        printf("Digite o %io valor: ", i);
        scanf("%d", &valor[i]);
        if(valor[i] < 0)
            negativos++;
        else
            positivos++;
    }
    printf("\nPositivos: %d\nNegativos: %d\n", positivos, negativos);

    system("pause");
}